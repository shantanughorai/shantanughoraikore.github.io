# BotKit

Kore Bot Server SDK is set of libraries which gives you more control over the bots you build on Kore Bots platform. Once you build the Dialog task using Dialog Editor, you can subscribe to all the message and webhook events. You can easily add event handlers in the SDK and get the handle over the messages and webhook events

Visit https://developer.kore.com/docs/bots/bot-builder/defining-bot-tasks/dialog-tasks/using-the-botkit-sdk/ for configuration instructions and API documentation.
