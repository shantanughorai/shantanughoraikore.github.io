var dit = {
    "server": {
        "port": 8006
    },
    "app": {
        "apiPrefix": "/botkit"
    },
    "credentials": {
        "apikey": "fTWr34+QqoqaT97wa4pAq9/4crX//ipyJnVRcLxkJS0=",
        "appId": "cs-b801d4e9-b510-54d6-9cc4-142fd8e7cb1d",
        "botId": "st-fc77c68b-a12c-5024-aae0-7aa1680690fa",
        "botName": "COVA"
    },
    "connect": {
        "api": ""
    },
    "redis": {
        "options": {
            "host": "localhost",
            "port": 6379
        },
        "available": false
    },
    "examples": {
        "mockServicesHost": "http://localhost:8004"
    },
    "liveagentlicense": "8947569",
    "supportsMessageAck": true,
    "languages": ["en", "de"]
};

module.exports = dit;