const DIT = require('./config_dit');
const CLOUD= require('./config_cloud');

//const env = process.env.NODE_ENV;

const env = "DIT";
const config = {
    DIT,
    CLOUD
};

module.exports = config[env]; 
