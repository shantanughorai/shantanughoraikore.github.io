var cloud = {
    "server": {
        "port": 8003
    },
    "app": {
        "apiPrefix": "/botkit"
    },
    "credentials": {
        "apikey": "g0zOy7/cjNqhU/Ubd9XjwJw/C1WG1aEjpIlOjngYjQQ=",
        "appId": "cs-ade0cb80-2336-532a-a884-38629aa94686",
        "botId": "st-41e89697-9594-54d8-b625-72404c51e7d2",
        "botName": "Citi CRS"
    },
    "connect": {
        "api": "https://dummy.account.com"
    },
    "redis": {
        "options": {
            "host": "localhost",
            "port": 6379
        },
        "available": false
    },
    "examples": {
        "mockServicesHost": "http://localhost:8004"
    },
    "liveagentlicense": "8947569",
    "supportsMessageAck": true,
    "languages": ["en", "de"]
};

module.exports = cloud;